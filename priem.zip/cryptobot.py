import aiohttp

CRYPTO_BOT_TOKEN = "540061:AADcpP4WKNOudNk0XwMOLDb79lwrSnmXgTo"
CRYPTO_BOT_API = "https://pay.crypt.bot/api"


async def create_invoice(amount: float, description: str, payload: str) -> dict | None:
    """Create an invoice in CryptoBot. Returns invoice dict or None on error."""
    url = f"{CRYPTO_BOT_API}/createInvoice"
    headers = {"Crypto-Pay-API-Token": CRYPTO_BOT_TOKEN}
    data = {
        "asset": "USDT",
        "amount": str(round(amount, 2)),
        "description": description,
        "payload": payload,
        "allow_comments": False,
        "allow_anonymous": False,
    }
    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(url, json=data, headers=headers) as resp:
                result = await resp.json()
                if result.get("ok"):
                    return result["result"]
                return None
    except Exception as e:
        print(f"CryptoBot createInvoice error: {e}")
        return None


async def create_check(amount: float, asset: str = "USDT") -> dict | None:
    """Create a check (чек) in CryptoBot. Returns check dict or None on error."""
    url = f"{CRYPTO_BOT_API}/createCheck"
    headers = {"Crypto-Pay-API-Token": CRYPTO_BOT_TOKEN}
    data = {
        "asset": asset,
        "amount": str(round(amount, 2)),
    }
    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(url, json=data, headers=headers) as resp:
                result = await resp.json()
                if result.get("ok"):
                    return result["result"]
                return None
    except Exception as e:
        print(f"CryptoBot createCheck error: {e}")
        return None


async def get_invoice(invoice_id: int) -> dict | None:
    """Get invoice status."""
    url = f"{CRYPTO_BOT_API}/getInvoices"
    headers = {"Crypto-Pay-API-Token": CRYPTO_BOT_TOKEN}
    data = {"invoice_ids": str(invoice_id)}
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url, params=data, headers=headers) as resp:
                result = await resp.json()
                if result.get("ok") and result["result"]["items"]:
                    return result["result"]["items"][0]
                return None
    except Exception as e:
        print(f"CryptoBot getInvoices error: {e}")
        return None
