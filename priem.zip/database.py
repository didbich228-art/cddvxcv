import aiosqlite
from datetime import date

DB_PATH = "bot.db"


async def init_db():
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("""
            CREATE TABLE IF NOT EXISTS users (
                user_id     INTEGER PRIMARY KEY,
                username    TEXT,
                full_name   TEXT,
                balance     REAL DEFAULT 0,
                total_sold  INTEGER DEFAULT 0,
                is_buyer    INTEGER DEFAULT 0,
                created_at  TEXT DEFAULT (date('now'))
            )
        """)
        await db.execute("""
            CREATE TABLE IF NOT EXISTS queue (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                phone       TEXT UNIQUE,
                seller_id   INTEGER,
                buyer_id    INTEGER,
                status      TEXT DEFAULT 'waiting',
                added_at    TEXT DEFAULT (datetime('now'))
            )
        """)
        await db.execute("""
            CREATE TABLE IF NOT EXISTS transactions (
                id              INTEGER PRIMARY KEY AUTOINCREMENT,
                seller_id       INTEGER,
                buyer_id        INTEGER,
                phone           TEXT,
                amount          REAL,
                status          TEXT DEFAULT 'pending',
                created_at      TEXT DEFAULT (datetime('now'))
            )
        """)
        await db.execute("""
            CREATE TABLE IF NOT EXISTS settings (
                key     TEXT PRIMARY KEY,
                value   TEXT
            )
        """)
        # defaults
        await db.execute("""
            INSERT OR IGNORE INTO settings VALUES ('price_per_number', '3')
        """)
        await db.execute("""
            INSERT OR IGNORE INTO settings VALUES ('min_withdraw', '3')
        """)
        await db.commit()


async def get_setting(key: str) -> str:
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute("SELECT value FROM settings WHERE key=?", (key,)) as cur:
            row = await cur.fetchone()
            return row[0] if row else None


async def set_setting(key: str, value: str):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("INSERT OR REPLACE INTO settings VALUES (?,?)", (key, value))
        await db.commit()


async def get_or_create_user(user_id: int, username: str, full_name: str):
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute("SELECT * FROM users WHERE user_id=?", (user_id,)) as cur:
            row = await cur.fetchone()
        if not row:
            await db.execute(
                "INSERT INTO users (user_id, username, full_name) VALUES (?,?,?)",
                (user_id, username, full_name)
            )
            await db.commit()
        else:
            await db.execute(
                "UPDATE users SET username=?, full_name=? WHERE user_id=?",
                (username, full_name, user_id)
            )
            await db.commit()


async def get_user(user_id: int) -> dict | None:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("SELECT * FROM users WHERE user_id=?", (user_id,)) as cur:
            row = await cur.fetchone()
            return dict(row) if row else None


async def is_buyer(user_id: int) -> bool:
    user = await get_user(user_id)
    return bool(user and user["is_buyer"])


async def set_buyer(user_id: int, status: bool):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("UPDATE users SET is_buyer=? WHERE user_id=?", (int(status), user_id))
        await db.commit()


async def add_to_queue(phone: str, seller_id: int) -> str:
    """Returns 'added' or 'duplicate'."""
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute("SELECT id FROM queue WHERE phone=?", (phone,)) as cur:
            if await cur.fetchone():
                return "duplicate"
        await db.execute(
            "INSERT INTO queue (phone, seller_id) VALUES (?,?)",
            (phone, seller_id)
        )
        await db.commit()
        return "added"


async def get_queue_position(phone: str) -> int:
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute(
            "SELECT COUNT(*)+1 FROM queue WHERE status='waiting' AND id < (SELECT id FROM queue WHERE phone=?)",
            (phone,)
        ) as cur:
            row = await cur.fetchone()
            return row[0] if row else 0


async def get_next_in_queue() -> dict | None:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT * FROM queue WHERE status='waiting' ORDER BY id ASC LIMIT 1"
        ) as cur:
            row = await cur.fetchone()
            return dict(row) if row else None


async def assign_queue_item(queue_id: int, buyer_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "UPDATE queue SET status='in_progress', buyer_id=? WHERE id=?",
            (buyer_id, queue_id)
        )
        await db.commit()


async def complete_queue_item(queue_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("UPDATE queue SET status='done' WHERE id=?", (queue_id,))
        await db.commit()


async def get_queue_item_by_id(queue_id: int) -> dict | None:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("SELECT * FROM queue WHERE id=?", (queue_id,)) as cur:
            row = await cur.fetchone()
            return dict(row) if row else None


async def get_queue_item_for_buyer(buyer_id: int) -> dict | None:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT * FROM queue WHERE buyer_id=? AND status='in_progress' ORDER BY id DESC LIMIT 1",
            (buyer_id,)
        ) as cur:
            row = await cur.fetchone()
            return dict(row) if row else None


async def get_waiting_count() -> int:
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute("SELECT COUNT(*) FROM queue WHERE status='waiting'") as cur:
            row = await cur.fetchone()
            return row[0] if row else 0


async def get_user_queue_count(seller_id: int) -> int:
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute(
            "SELECT COUNT(*) FROM queue WHERE seller_id=? AND status='waiting'", (seller_id,)
        ) as cur:
            row = await cur.fetchone()
            return row[0] if row else 0


async def get_user_sold_today(seller_id: int) -> int:
    today = date.today().isoformat()
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute(
            "SELECT COUNT(*) FROM transactions WHERE seller_id=? AND status='paid' AND date(created_at)=?",
            (seller_id, today)
        ) as cur:
            row = await cur.fetchone()
            return row[0] if row else 0


async def create_transaction(seller_id: int, buyer_id: int, phone: str, amount: float) -> int:
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            "INSERT INTO transactions (seller_id, buyer_id, phone, amount) VALUES (?,?,?,?)",
            (seller_id, buyer_id, phone, amount)
        )
        await db.commit()
        return cur.lastrowid


async def get_transaction(tx_id: int) -> dict | None:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("SELECT * FROM transactions WHERE id=?", (tx_id,)) as cur:
            row = await cur.fetchone()
            return dict(row) if row else None


async def get_unpaid_transaction_for_buyer(buyer_id: int) -> dict | None:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT * FROM transactions WHERE buyer_id=? AND status='pending' ORDER BY id DESC LIMIT 1",
            (buyer_id,)
        ) as cur:
            row = await cur.fetchone()
            return dict(row) if row else None


async def pay_transaction(tx_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        tx = await get_transaction(tx_id)
        if tx:
            await db.execute(
                "UPDATE transactions SET status='paid' WHERE id=?", (tx_id,)
            )
            await db.execute(
                "UPDATE users SET balance=balance+?, total_sold=total_sold+1 WHERE user_id=?",
                (tx["amount"], tx["seller_id"])
            )
            await db.commit()


async def withdraw_balance(user_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute("SELECT balance FROM users WHERE user_id=?", (user_id,)) as cur:
            row = await cur.fetchone()
            balance = row[0] if row else 0
        await db.execute("UPDATE users SET balance=0 WHERE user_id=?", (user_id,))
        await db.commit()
        return balance
